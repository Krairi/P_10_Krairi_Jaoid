#!/usr/bin/env python
# Copyright (c) Microsoft Corporation. All rights reserved.
# Licensed under the MIT License.
"""Configuration for the bot."""
# APP_ID = os.environ.get("MicrosoftAppId", "e6383980-891e-4375-b08d-0deada9dcde5")

import os


class DefaultConfig:
    """Configuration for the bot."""

    PORT = 8000
    APP_ID = os.environ.get("MicrosoftAppId", "")
    APP_PASSWORD = os.environ.get("MicrosoftAppPassword", "")
    LUIS_APP_ID = os.environ.get("LuisAppId", "d5aedfec-a268-4ada-89d3-b002561d9180")
    LUIS_API_KEY = os.environ.get("LuisAPIKey", "d06c7abdf7444166b6fd614a51cb285c")
    # LUIS endpoint host name, ie "westus.api.cognitive.microsoft.com"
    LUIS_API_HOST_NAME = os.environ.get("LuisAPIHostName", "authojk.cognitiveservices.azure.com")
    APPINSIGHTS_INSTRUMENTATION_KEY = os.environ.get(
        "AppInsightsInstrumentationKey", "661113ce-d214-43b0-a947-a4b3f3a0bfae"
    )
